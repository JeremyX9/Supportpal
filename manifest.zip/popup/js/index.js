// grab all content elements with id "content"
console.log("popup opened")
var contents = document.querySelectorAll("#content");

// add to all content elements the class "hidden" except the first one
toggleContent("webserver")

// add a event listener to all elements with class "sub-heading" if clicked 

var subHeadings = document.querySelectorAll(".sub-heading");

for (var i = 0; i < subHeadings.length; i++) {
    subHeadings[i].addEventListener("click", function () {
        toggleContent(this.getAttribute("data-id"));
    });
}

function toggleContent(except) {
    for (var i = 0; i < contents.length; i++) {
        if (contents[i].getAttribute("data-value") != except) {
            contents[i].classList.add("hidden");
        } else {
            contents[i].classList.remove("hidden");
        }
    }
}

let ipv4 = "";
let ipv6 = "";
let hostname = "";
let servername = "";
let nameserver = "";



browser.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var activeTab = tabs[0];
    let url = new URL(activeTab.url);
    var hostname = url.hostname;
    document.getElementById("domain").innerHTML = hostname;
    // Hier kannst du den Hostnamen verwenden, um die API-URL zu generieren
    let ipv4Url = "https://dns.google/resolve?name=" + hostname + "&type=A";
    let ipv6Url = "https://dns.google/resolve?name=" + hostname + "&type=AAAA";
    let nameserverUrl = "https://dns.google/resolve?name=" + hostname + "&type=NS";
    let mailserverUrl = "https://dns.google/resolve?name=" + url.hostname.split(".").reverse()[1] + "." + url.hostname.split(".").reverse()[0] + "&type=MX";

    fetch(ipv4Url)
        .then(response => response.json())
        .then(data => {
            console.log(data["Answer"][0]["data"]);
            ipv4 = data["Answer"][0]["data"];
            document.getElementById("ipv4").innerHTML = ipv4;

            let reverseIp = ipv4.split(".").reverse().join(".");
            let ptrUrl = "https://dns.google/resolve?name=" + reverseIp + ".in-addr.arpa&type=PTR";
            fetch(ptrUrl)

                .then(response => response.json())
                .then(data => {
                    console.log(data["Answer"][0]["data"]);
                    servername = data["Answer"][0]["data"];
                    document.getElementById("servername").innerHTML = servername;
                })
                .catch(error => {
                    console.log("no valid ptr record found");
                    servername = "";
                });
        })
        .catch(error => {
            console.error("Fehler beim Abrufen der API-Daten:", error);
        });
    fetch(ipv6Url)
        .then(response => response.json())
        .then(data => {
            console.log(data["Answer"][0]["data"]);
            ipv6 = data["Answer"][0]["data"];
            document.getElementById("ipv6").innerHTML = ipv6;
        })
        .catch(error => {
            document.getElementById("ipv6").innerHTML = "---";
            console.log("no valid ipv6 record found");
        });
    fetch(nameserverUrl)
        .then(response => response.json())
        .then(data => {
            nameserver = data["Answer"][0]["data"].split(" ")[0] + " " + data["Answer"][0]["data"].split(" ")[1];
            document.getElementById("nameserver").innerHTML = nameserver;
        })
        .catch(error => {
            document.getElementById("nameserver").innerHTML = "---";
            console.log(error);
            console.log("no valid namerserver record found");
        });
    fetch(mailserverUrl)
        .then(response => response.json())
        .then(data => {
            console.log("---------------------------");
            let mailserver = data["Answer"][0]["data"].split(" ")[1];
            let priority = data["Answer"][0]["data"].split(" ")[0];
            document.getElementById("mailserver").innerHTML = mailserver;
            document.getElementById("mail-priority").innerHTML = priority;
        })
        .catch(error => {
            document.getElementById("mailserver").innerHTML = "---";
            console.log("no valid mailserver record found" + error);
        });
});
